### IMBOR2025
* IMBOR Vocabulaire
  * https://hub.laces.tech/crow/imbor/2025/p/vocabulaire/sparql
* IMBOR Kern
  * https://hub.laces.tech/crow/imbor/2025/p/kern/sparql
* IMBOR Domeinwaarden
  * https://hub.laces.tech/crow/imbor/2025/p/domeinwaarden/sparql
* IMBOR Aanvullend metamodel
  * https://hub.laces.tech/crow/imbor/2025/p/aanvullend-metamodel/sparql
* IMBOR Addendum Geometrie
  * https://hub.laces.tech/crow/imbor/2025/p/ad-geometrie/sparql
* IMBOR Addendum Materie
  * https://hub.laces.tech/crow/imbor/2025/p/ad-materie/sparql
* IMBOR Addendum OAGBD
  * https://hub.laces.tech/crow/imbor/2025/p/ad-oagbd/sparql
* IMBOR Addendum Referentiemodellen
  * https://hub.laces.tech/crow/imbor/2025/p/ad-refmodels/sparql
* IMBOR Addendum MIM
  * https://hub.laces.tech/crow/imbor/2025/p/ad-mim/sparql
* IMBOR Volledig-CombiGraph
  * https://hub.laces.tech/crow/imbor/2025/p/volledig-combigraph/sparql  
* IMBOR Changelog
  * https://hub.laces.tech/crow/imbor/2025/p/changelog/sparql


### IMBOR2022
* IMBOR Vocabulaire
  * https://hub.laces.tech/crow/imbor/2022/p/vocabulaire/sparql
* IMBOR Kern
  * https://hub.laces.tech/crow/imbor/2022/p/kern/sparql
* IMBOR Domeinwaarden
  * https://hub.laces.tech/crow/imbor/2022/p/domeinwaarden/sparql
* IMBOR Informatief
  * https://hub.laces.tech/crow/imbor/2022/p/informatief/sparql
* IMBOR Aanvullend metamodel
  * https://hub.laces.tech/crow/imbor/2022/p/aanvullend-metamodel/sparql
